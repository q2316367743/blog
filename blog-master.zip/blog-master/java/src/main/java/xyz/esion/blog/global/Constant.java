package xyz.esion.blog.global;

/**
 * @author qiao shengda
 * @since 2021/7/11
 */
public class Constant {

    /**
     * 静态服务器根目录
     * */
    public static String ROOT_PATH;

    /**
     * 静态服务器图片存放目录
     * */
    public static String IMAGE_PATH;

    /**
     * 静态服务器音乐存放目录
     * */
    public static String MUSIC_PATH;

}
