<template>
	<el-col :span="24">
		<div id="article-main">
			<div id="article-title">
				<el-row>
					<el-col :span="2" style="min-height: 1px"></el-col>
					<el-col :span="20">
						<div
							style="font-size: 34px"
							v-text="article.title"
						></div>
						<div style="font-size: 14px">
							<div style="margin-top: 10px">
								<span><i class="el-icon-date"></i> 发表于</span>
								<span v-text="article.create_time"></span>
								<span> | </span>
								<span
									><i class="el-icon-refresh"></i>
									更新于</span
								>
								<span v-text="article.update_time"></span>
							</div>
							<div>
								<span
									><i class="el-icon-document"></i>
									字数总计:</span
								>
								<span v-text="article.word_count"></span>
								<span> | </span>
								<span
									><i class="el-icon-time"></i>
									阅读时长:</span
								>
								<span>{{ article.read_time }}分钟</span>
								<span> | </span>
								<span
									><i class="el-icon-view"></i> 阅读量:</span
								>
								<span v-text="article.view_count"></span>
								<span> | </span>
								<span
									><i class="el-icon-chat-line-square"></i>
									评论数:</span
								>
								<span v-text="article.comment_count"></span>
							</div>
						</div>
					</el-col>
				</el-row>
			</div>
		</div>
		<el-col
			:span="6"
			:xs="1"
			:sm="2"
			:md="3"
			:lg="4"
			:xl="6"
			style="min-height: 1px"
		>
		</el-col>
		<el-col :span="12" :xs="22" :sm="20" :md="18" :lg="16" :xl="12">
			<el-card shadow="always">
				<div class="content">
					<!-- 文章内容 -->
					<div
						style="margin-top: 20px"
						v-html="article.content"
						class="typo"
					></div>
					<div class="export-info">
						<div>
							<span class="export-title">文章作者：</span>
							<span
								><a href="mailto:m17762618644@163.com"
									>云落天都</a
								></span
							>
						</div>
						<div>
							<span class="export-title">文章链接：</span>
							<span><a :href="href" v-text="href"></a></span>
						</div>
						<div>
							<span class="export-title">版权声明：</span>
							<span
								>本博客所有文章除特别声明外，均采用<a
									href="https://creativecommons.org/licenses/by-nc-sa/4.0/"
								>
									CC BY-NC-SA 4.0 </a
								>许可协议。转载请注明来自<a
									href="mailto:m17762618644@163.com"
								>
									落雨不悔的博客</a
								>！</span
							>
						</div>
					</div>
					<div class="share">
						<a href="javascript:void(0);"
							><i
								class="layui-icon layui-icon-login-wechat"
								style="color: #83d942"
							></i>
						</a>
						<a href="javascript:void(0);"
							><i
								class="layui-icon layui-icon-login-qq"
								style="color: #26cbfe"
							></i>
						</a>
						<a href="javascript:void(0);"
							><i
								class="layui-icon layui-icon-login-weibo"
								style="color: #ed221b"
							></i>
						</a>
					</div>
					<el-divider content-position="left">我是分割线</el-divider>
					<div class="comment">
						<div class="comment-title">
							<i class="el-icon-chat-line-square"></i> 评论
						</div>
						<el-card shadow="always" class="comment-content">
							<el-row>
								<el-col :span="8">
									<el-input
										v-model="comment.nickname"
										placeholder="昵称（必填）"
									></el-input>
								</el-col>
								<el-col :span="8">
									<el-input
										v-model="comment.email"
										placeholder="邮箱（必填）"
									></el-input>
								</el-col>
								<el-col :span="8">
									<el-input
										v-model="comment.website"
										placeholder="个人网站（选填）"
									></el-input>
								</el-col>
							</el-row>
							<textarea
								id="comment"
								placeholder="1、昵称可自定义，大于3个字符即可。2、邮箱建议填写qq邮箱，可以收到评论回复，且评论区头像就可以采用QQ头像。"
							></textarea>
							<div style="margin-top: 10px;text-align: right">
								<el-button type="primary" @click="submitComment"
									>提交</el-button
								>
							</div>
						</el-card>
					</div>
					<div class="comment">
						<div
							class="comment-title"
							style="color: #49b1f5; margin-bottom: 40px"
						>
							<span v-text="comments.length"></span>
							<span> 评论</span>
						</div>
						<el-card
							shadow="always"
							style="margin-top: 20px"
							v-for="(comment, index) in comments"
							:key="index"
						>
							<el-row>
								<el-col
									:span="2"
									style="
										text-align: right;
										padding-right: 5px;
									"
								>
									<el-image
										class="comment-image"
										:src="
											'https://q2.qlogo.cn/headimg_dl?dst_uin=' +
											comment.email +
											',1583720084,&spec=100'
										"
									></el-image>
								</el-col>
								<el-col :span="22" style="padding-left: 5px">
									<div>
										<a
											href="javascript:void(0);"
											v-text="comment.nickname"
										></a>
										<el-tag
											type="info"
											size="mini"
											style="margin-left: 5px"
											v-if="comment.type === 1"
										>
											<i
												class="layui-icon layui-icon-username"
											></i>
											<span>访客</span>
										</el-tag>
										<el-tag
											type="success"
											size="mini"
											style="margin-left: 5px"
											v-else-if="comment.type === 2"
										>
											<i
												class="layui-icon layui-icon-username"
											></i>
											<span>小伙伴</span>
										</el-tag>
										<el-tag
											type="warning"
											size="mini"
											style="margin-left: 5px"
											v-else-if="comment.type === 3"
										>
											<i
												class="layui-icon layui-icon-username"
											></i>
											<span>博主</span>
										</el-tag>
										<el-tag
											size="mini"
											style="margin-left: 5px"
										>
											<i
												class="layui-icon layui-icon-website"
											></i>
											<span
												v-text="comment.browser"
											></span>
										</el-tag>
										<el-tag
											size="mini"
											style="margin-left: 5px"
										>
											<i
												class="layui-icon layui-icon-windows"
											></i>
											<span
												v-text="comment.system_version"
											></span>
										</el-tag>
									</div>
									<div
										style="
											display: flex;
											justify-content: space-between;
											margin-top: 5px;
										"
									>
										<div
											style="
												color: #49b1f5;
												font-size: 14px;
											"
											v-text="comment.create_time"
										></div>
										<div>
											<el-button
												size="mini"
												@click="reply(comment.id, comment.nickname)"
												>回复</el-button
											>
										</div>
									</div>
									<div
										style="margin-top: 10px"
										v-html="comment.content"
									></div>
								</el-col>
							</el-row>
							<el-row v-if="comment.children && comment.children.length > 0">
								<el-row
									v-for="(item, index) in comment.children"
									:key="index"
									style="margin-top: 40px"
								>
									<el-col
										:span="2"
										:offset="1"
										style="
										text-align: right;
										padding-right: 5px;
									"
									>
										<el-image
											class="comment-image-reply"
											:src="
											'https://q2.qlogo.cn/headimg_dl?dst_uin=' +
											item.email +
											',1583720084,&spec=100'
										"
										></el-image>
									</el-col>
									<el-col :span="21" style="padding-left: 5px">
										<div>
											<a
												:href="item.website.length > 0 ? item.website.length : 'javascript:void(0);'"
												v-text="item.nickname"
											></a>
											<el-tag
												type="info"
												size="mini"
												style="margin-left: 5px"
												v-if="item.type === 1"
											>
												<i
													class="layui-icon layui-icon-username"
												></i>
												<span>访客</span>
											</el-tag>
											<el-tag
												type="success"
												size="mini"
												style="margin-left: 5px"
												v-else-if="item.type === 2"
											>
												<i
													class="layui-icon layui-icon-username"
												></i>
												<span>小伙伴</span>
											</el-tag>
											<el-tag
												type="warning"
												size="mini"
												style="margin-left: 5px"
												v-else-if="item.type === 3"
											>
												<i
													class="layui-icon layui-icon-username"
												></i>
												<span>博主</span>
											</el-tag>
											<el-tag
												size="mini"
												style="margin-left: 5px"
											>
												<i
													class="layui-icon layui-icon-website"
												></i>
												<span
													v-text="item.browser"
												></span>
											</el-tag>
											<el-tag
												size="mini"
												style="margin-left: 5px"
											>
												<i
													class="layui-icon layui-icon-windows"
												></i>
												<span
													v-text="item.system_version"
												></span>
											</el-tag>
										</div>
										<div
											style="
											display: flex;
											justify-content: space-between;
											margin-top: 5px;
										"
										>
											<div
												style="
												color: #49b1f5;
												font-size: 14px;
											"
												v-text="item.create_time"
											></div>
											<div>
												<el-button
													size="mini"
													@click="reply(item.id, item.nickname)"
												>回复</el-button
												>
											</div>
										</div>
										<div style="margin-top: 10px">
											<a :href="item.target_website.length > 0 ? item.target_website : 'javascript:void(0);'">
												<span>@</span>
												<span
													v-text="
													item.target_nickname
												"
												></span>
											</a>
											<span>, </span>
											<span
												v-html="item.content"
											></span>
										</div>
									</el-col>
								</el-row>
							</el-row>
						</el-card>
					</div>
				</div>
			</el-card>
		</el-col>
	</el-col>
</template>

<script>
import { findDimensions } from "@/utils/window";
import $ from "jquery";
import { getArticle } from "@/api/article";
import { getComment, addComment, addReply } from "@/api/comment";
import hljs from "highlight.js";
import './typo.css'
import "highlight.js/styles/dracula.css";
import showdown from "showdown";
let converter = new showdown.Converter();
converter.setOption("tables", true); // 将表格显示出来

let isAdd = true;

const highlightCode = () => {
	const preEl = document.querySelectorAll("pre");

	preEl.forEach((el) => {
		hljs.highlightBlock(el);
	});

	if (preEl.length > 0 && isAdd) {
		$("code").each(function () {
			$(this).html(
				"<ol><li>" +
					$(this).html().replace(/\n/g, "\n</li><li>") +
					"\n</li></ol>"
			);
		});
		isAdd = false;
	}

	preEl.forEach((pre) => {
		pre.addEventListener("contextmenu", function (e) {
			let text = e.currentTarget.innerText;
			window.layer.open({
				type: 1,
				title: "代码",
				content:
					"<textarea id='copyCode' style='width: 99%;height: 97%;border-color: #ffffff;'> " +
					text +
					" </textarea>",
				area: ["800px", "350px"],
			});
			$("#copyCode").select();
			e.preventDefault();
		});
	});
};

export default {
	data() {
		return {
			id: 0,
			winWidth: 0,
			winHeight: 0,
			href: "",
			article: {
				title: "",
				create_time: "",
				update_time: "",
				count: 0,
				read_time: 0,
				view_count: 0,
				comment_count: 0,
                word_count: 0,
				content: "",
			},
			catalog: [],
			comment: {
				nickname: "",
				email: "",
				website: "",
				content: "",
			},
			editIndex: -1,
			replyIndex: -1,
			replyDialogIndex: -1,
			comments: [],
			step: 0,
			loading: null,
		};
	},
	created() {
		// 获取文章信息
		this.href = window.location.href;
		// 获取文章信息
		this.id = this.$route.params.id;
		getArticle(this.$route.params.id, (res) => {
			if (res.success) {
				this.article = res.data.item;
				this.article.content = converter.makeHtml(this.article.content)
				this.createCatalog();
				this.step++;
			} else {
				window.layer.alert("文章错误");
				this.$router.go(-1);
			}
		});
		getComment(this.$route.params.id, (res) => {
			console.log(res)
			if (res.success) {
				this.comments = res.data.items;
				this.step += 2;
			}
		});
	},
	mounted() {
		this.loading = this.$loading({
			lock: true,
			text: "Loading",
			spinner: "el-icon-loading",
			background: "rgba(0, 0, 0, 0.7)",
		});
		// 监听窗口大小
		this.getWindow();
		window.onresize = this.getWindow;
		// 增加复制监听器
		document.addEventListener("copy", (e) => {
			let node = document.createElement("div");
			// cloneContents方法把范围（Range）的内容复制到一个DocumentFragment对象
			node.appendChild(
				window.getSelection().getRangeAt(0).cloneContents()
			);
			let copyInfo = node.innerText;
			if (e.path[0].value) {
				return;
			}
			let link =
				"\n\n\n文章作者：落雨不悔\n文章链接：http://localhost:8080/#/article/1\n版权声明：本博客所有文章除特别声明外，均采用 CC BY-NC-SA 4.0 许可协议。转载请注明来自 落雨不悔的博客！";
			copyInfo = copyInfo + link;

			if (e.clipboardData) {
				e.clipboardData.setData("text/plain", copyInfo);
			} else if (window.clipboardData) {
				return window.clipboardData.setData("text", copyInfo);
			}
			e.preventDefault();
			e.stopPropagation();
		});

		// 构建评论
		// 应该加入定时函数，查找class => layui-layedit
		let that = this;
		let interval = setInterval(() => {
			if (window.layedit && $(".layui-layedit").length === 0) {
				that.editIndex = window.layedit.build("comment", {
					height: 180, //设置编辑器高度
					hideTool: ["image"],
				}); //建立编辑器
				clearInterval(interval);
			}
		}, 100);
		highlightCode();
		// 确定当前步骤
		let count = 0;
		let inter = setInterval(()=>{
			if(that.step === 3){
				that.loading.close();
				clearInterval(inter);
			}
			if(count === 4){
				if(that.step === 0){
					window.layer.msg('文章加载失败');
					that.$router.go(-1);
				}
				if(that.step === 1){
					window.layer.alert('评论加载失败', function(){
						that.$router.go(-1);
					})
				}
				if(that.step === 2){
					window.layer.msg('文章加载失败');
					that.$router.go(-1);
				}
				that.loading.close();
				clearInterval(inter);
			}
			count++;
		}, 500)
	},
	updated() {
		highlightCode();
		let that = this;
		if (window.layedit && that.editIndex === -1) {
			that.editIndex = window.layedit.build("comment", {
				height: 180, //设置编辑器高度
				hideTool: ["image"],
			}); //建立编辑器
		}
		if (this.article.content && this.article.content.length > 0) {
			// 有内容，增加事件
			$("img").on("click", function (e) {
				window.layer.open({
					type: 1,
					title: false,
					closeBtn: 0,
					area: ["auto"],
					skin: "layui-layer-nobg", //没有背景色
					shadeClose: true,
					content:
						'<img alt="" src="' + $(e.currentTarget).attr("src") + '" />',
				});
			});
		}
	},
	destroyed() {
		$("img").unbind("click");
		isAdd = true;
	},
	methods: {
		getWindow() {
			findDimensions((winWidth, winHeight) => {
				this.winWidth = winWidth;
				this.winHeight = winHeight;
			});
            let article_title = $("#article-title");
            let article_main = $("#article-main");
            article_title.css("width", this.winWidth);
            article_main.css("width", this.winWidth);
			let h = this.winHeight / 3;
			if (h > 152) {
                article_title.css("padding-top", h - 23);
                article_main.css("height", h * 2 - 92);
			}

			this.$parent.isSm = this.winWidth < 768;
		},
		/**
		 * 创建目录
		 */
		createCatalog() {},
		/**
		 * 提交评论
		 */
		submitComment() {
			//判断是否填写信息
			if (this.comment.nickname.length === 0) {
				window.layer.msg("未填写昵称");
				return;
			}
			if (this.comment.email.length === 0) {
				window.layer.msg("未填写邮箱");
				return;
			}
			let email_verify = /^([a-zA-Z0-9]+[_|_|.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|_|.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
			if(!email_verify.test(this.comment.email)){
				window.layer.msg("请填写正确的邮箱");
				return;
			}
			this.comment.content = window.layedit.getContent(this.editIndex);
			if (this.comment.content.length === 0) {
				window.layer.msg("未填写内容");
				return;
			}
			if (this.comment.content.length > 255){
				window.layer.msg("内容最多支持输入255字");
				return;
			}
			let appVersion = window.navigator.appVersion.split(" ");
			let osVersion =
				appVersion[1].substring(1, appVersion[1].length) +
				" " +
				appVersion[3].substring(0, appVersion[3].length - 1);
			let browser_version = appVersion[appVersion.length - 1];
			this.comment.system_version = osVersion;
			this.comment.browser = browser_version;
			this.comment.article_id = this.id;
			addComment(this.comment, (res) => {
				if (res.success) {
					window.layer.msg("评论成功，审核中");
					//重新构建编辑器
					this.editIndex = window.layedit.build("comment", {
						height: 180, //设置编辑器高度
						hideTool: ["image"],
					});
				}
			});
			this.comment = {
				nickname: "",
				email: "",
				website: "",
				content: "",
			};
		},
		reply(id, nickname) {
			let article_id = this.id;
			// 打开对话框
			if (this.replyDialogIndex !== -1) {
				window.layer.close(this.replyDialogIndex);
				this.replyDialogIndex = -1;
			}
			this.replyDialogIndex = window.layer.open({
				type: 1,
				title: "回复 " + nickname,
				content:
                    '<div style="padding: 10px 20px;">' +
					'<div class="layui-row">' +
					'<div class="layui-col-md4">' +
					'<input type="text" id="nickname" class="layui-input" placeholder="昵称（必填）">' +
					"</div>" +
					'<div class="layui-col-md4">' +
					'<input type="text" id="email" class="layui-input" placeholder="邮箱（必填）">' +
					"</div>" +
					'<div class="layui-col-md4">' +
					'<input type="text" id="website" class="layui-input" placeholder="个人网站（选填）">' +
					"</div>" +
					"</div>" +
					'<textarea id="reply"></textarea>' +
					'<div style="margin-top: 10px;text-align: right;"><button id="addReply" class="layui-btn" style="background-color: #409EFF;">提交</button></div>' +
                    '</div>',
				area: ["520px", "380px"],
			});
			//建立编辑器
			let that = this;
			this.replyIndex = window.layedit.build("reply", {
				height: 180, //设置编辑器高度
				hideTool: ["image"],
			});
			// 增加评论事件
			$("#addReply").on("click", function () {
				// 获取信息
				let nickname = $("#nickname").val();
				let email = $("#email").val();
				let website = $("#website").val();
				let content = window.layedit.getContent(that.replyIndex);
				if (length === 0) {
					window.layer.msg("未填写昵称");
					return;
				}
				if (email.length === 0) {
					window.layer.msg("未填写邮箱");
					return;
				}
				let email_verify = /^([a-zA-Z0-9]+[_|_|.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|_|.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
				if(!email_verify.test(email)){
					window.layer.msg("请填写正确的邮箱");
					return;
				}
				if (content.length === 0) {
					window.layer.msg("未填写内容");
					return;
				}
				if (content.length > 255) {
					window.layer.msg("内容最多支持输入255字");
					return;
				}
				let appVersion = window.navigator.appVersion.split(" ");
				let osVersion =
					appVersion[1].substring(1, appVersion[1].length) +
					" " +
					appVersion[3].substring(0, appVersion[3].length - 1);
				let browser_version = appVersion[appVersion.length - 1];
				// 增加回复
				addReply(
					{
						nickname: nickname,
						email: email,
						website: website,
						content: content,
						system_version: osVersion,
						browser: browser_version,
						comment_id: id,
						article_id: article_id
					},
					(res) => {
						if (res.success) {
							window.layer.msg("回复成功，审核中");
						}
					}
				);
				window.layer.close(that.replyDialogIndex);
				that.replyDialogIndex = -1;
			});
		},
	},
};
</script>

<style>
#article-main {
	color: #ffffff;
}
.content {
	font-size: 16px;
	padding-left: 10px;
}

.export-info {
	border: 1px solid #eeeeee;
	padding: 20px;
	margin: 40px auto 10px auto;
}
.export-title {
	font-weight: bold;
	color: #49b1f5;
}

.share {
	text-align: right;
}
.share i {
	font-size: 26px;
	padding-left: 5px;
}

.comment {
	margin-top: 40px;
}
.comment-title {
	font-size: 20px;
	font-weight: bold;
	color: #424242;
}
.comment-content {
	margin-top: 20px;
}
.comment-content input {
	border-color: #ffffff;
}
.comment-image {
	text-align: right;
	width: 40px;
	height: 40px;
	border-radius: 20px;
}
.comment-image-reply {
	text-align: right;
	width: 30px;
	height: 30px;
	border-radius: 15px;
}
.layui-input {
	border-color: #ffffff;
}

.hljs ol {
	list-style: decimal;
	margin: 0 0 0 40px !important;
	padding: 0;
}
.hljs ol li {
	list-style: decimal-leading-zero;
	border-left: 1px solid #ddd !important;
	padding: 5px !important;
	margin: 0 !important;
	white-space: pre;
	font-family: JetBrainsMono,Consolas,serif;
}
</style>