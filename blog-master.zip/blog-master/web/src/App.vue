<template>
	<div id="app" @scroll="appScroll($event)">
		<div :class="{ topT: isT, topS: !isT }" v-show="showTop">
			<div
				style="
					display: flex;
					flex-flow: row nowrap;
					justify-content: space-between;
				"
			>
				<div>
					<div class="logo" :class="{ 'nav-item-a': scrollOver }">
						<router-link tag="a" to="/">落雨不悔的博客</router-link>
					</div>
				</div>
				<div v-show="!isSm">
					<ul class="nav" :class="{ 'nav-item-a': scrollOver }">
						<li class="nav-item" @click="search_click">
							<i class="el-icon-search" style="color: #1abc9c;font-weight: bold;font-size: 16px;"></i>
							<span>搜索</span>
						</li>
						<li class="nav-item" to="/">
							<svg class="icon" aria-hidden="true">
								<use xlink:href="#icon-zhuye"></use>
							</svg>
							<span>首页</span>
						</li>
						<li class="nav-item" to="/shijianzhou">
							<svg class="icon" aria-hidden="true">
								<use xlink:href="#icon-shijianzhou"></use>
							</svg>
							<a href="javascript:void(0);"> 时间轴</a>
						</li>
						<li class="nav-item" to="/category">
							<svg class="icon" aria-hidden="true">
								<use
									xlink:href="#icon-leimupinleifenleileibie"
								></use>
							</svg>
							<a href="javascript:void(0);"> 分类</a>
						</li>
						<li class="nav-item" to="/about">
							<svg
								class="icon"
								aria-hidden="true"
								style="font-size: 18px"
							>
								<use xlink:href="#icon-mingpian-copy"></use>
							</svg>
							<a href="javascript:void(0);"> 关于作者</a>
						</li>
					</ul>
				</div>
				<div v-show="isSm" style="padding: 0 20px;cursor: pointer">
					<i
						class="el-icon-menu"
						style="font-size: 20px;"
						@click="openMenu"
					></i>
				</div>
			</div>
		</div>
		<router-view></router-view>

		<!-- 底部 -->
		<div id="fix-bar"></div>
		<el-col :span="24" class="footer">
			<div>©2020 - 2021 By Esion</div>
		</el-col>

		<!-- 回到顶部 -->
		<el-backtop
			target="#app"
			:bottom="40"
			:right="8"
			style="
				border-radius: 0;
				background-color: transparent;
				box-shadow: 0 0 0;
				width: 30px;
				height: 30px;
			"
		>
			<div class="back_top">
				<i class="el-icon-top"></i>
			</div>
		</el-backtop>
		<!-- 设置音乐显示 -->
		<fix-bar target="#app" :bottom="70" :right="8" @click="isShowMusic()">
			<div class="back_top">
				<span class="iconfont icon-yinle"></span>
			</div>
		</fix-bar>

		<!-- 侧边菜单 -->
		<el-drawer
			:visible.sync="menuShow"
			direction="rtl"
			:show-close="false"
			size="250"
		>
			<div style="width: 205px; text-align: left">
				<div style="margin-top: 10%; margin-bottom: 100px">
					<ul class="nav" :class="{ 'nav-item-a': scrollOver }">
						<li class="nav-item" @click="search_click">
							<i class="el-icon-search" style="color: #1abc9c;font-weight: bold;font-size: 16px;"></i>
							<span>搜索</span>
						</li>
						<br/>
						<li class="nav-item" to="/">
							<svg class="icon" aria-hidden="true">
								<use xlink:href="#icon-zhuye"></use>
							</svg>
							<span>首页</span>
						</li>
						<li class="nav-item" to="/shijianzhou">
							<svg class="icon" aria-hidden="true">
								<use xlink:href="#icon-shijianzhou"></use>
							</svg>
							<a href="javascript:void(0);"> 时间轴</a>
						</li>
						<li class="nav-item" to="/tag">
							<svg
								class="icon"
								aria-hidden="true"
								style="font-size: 16px"
							>
								<use xlink:href="#icon-biaoqian"></use>
							</svg>
							<a href="javascript:void(0);"> 标签</a>
						</li>
						<li class="nav-item" to="/category">
							<svg class="icon" aria-hidden="true">
								<use
									xlink:href="#icon-leimupinleifenleileibie"
								></use>
							</svg>
							<a href="javascript:void(0);"> 分类</a>
						</li>
						<li class="nav-item" to="/about">
							<svg
								class="icon"
								aria-hidden="true"
								style="font-size: 18px"
							>
								<use xlink:href="#icon-mingpian-copy"></use>
							</svg>
							<a href="javascript:void(0);"> 关于作者</a>
						</li>
					</ul>
				</div>
			</div>
		</el-drawer>
		<div class="search-main" v-if="is_search">
			<div class="search-background" @click="is_search = false"></div>
			<div class="search-input">
				<el-input ref="search" style="max-width: 500px" placeholder="请输入文章标题" @keyup.enter.native="search" v-model="title"></el-input>
			</div>
		</div>
	</div>
</template>

<script>
import $ from "jquery";
import { get_config, get_author, get_web_info, get_category_top } from "@/api/global";
import fix_bar from "@/components/fixbar";

import "aplayer/dist/APlayer.min.css";
import APlayer from "aplayer";

export default {
	name: "App",
	components: {
		"fix-bar": fix_bar,
	},
	data() {
		return {
			audio: null,
			scrollTop: 0,
			targetTop: true,
			isTop: true,
			isT: true,
			showTop: true,
			scrollOver: false,
			isSm: false,
			menuShow: false,
			baseInfo: {
				background: "",
				music: [],
			},
			showMusic: true,
			// 是否搜索
			is_search: false,
			title: ''
		};
	},
	mounted() {
		//获取基本信息
		get_config((res) => {
			if (res.success) {
				let baseInfo = res.data.item;
				new APlayer({
					container: document.getElementById("fix-bar"),
					fixed: true,
					loop: "all",
					audio: baseInfo.music,
				});
				$("#app").css(
					"background-image",
					"url(" + baseInfo.background + ")"
				);
			}
		});
		
		get_author((res) => {
			if (res.success) {
				this.$store.commit("SET_AUTHOR", res.data.item);
			}
		});
		get_web_info((res) => {
			if (res.success) {
				this.$store.commit("SET_WEB_INFO", res.data.item);
				this.$store.commit("SET_NOTICES", res.data.items);
			}
		});
		get_category_top(res=>{
			if (res.success) {
				this.$store.commit("SET_CATEGORY", res.data.items);
			}
		})

		let that = this;
		// 增加事件
		$(".nav-item").on("click", function (e) {
			if ($(e.currentTarget).attr("to")){
				that.$router.push($(e.currentTarget).attr("to"));
			}
		});
	},
	watch: {
		$route() {
			// 返回顶部
			$("#app").animate({scrollTop: "0px"}, 800);
		},
	},
	methods: {
		appScroll(e) {
			this.isTop = e.target.scrollTop === 0;
			this.targetTop = e.target.scrollTop - this.scrollTop < 0;
			this.scrollTop = e.target.scrollTop;
			this.scrollOver = e.target.scrollTop > 60;
			if (this.scrollOver) {
				if (this.targetTop) {
					if (!this.isTop) {
						this.showTop = true;
					}
				} else {
					this.showTop = false;
				}
				this.isT = false;
			} else {
				this.showTop = true;
				this.isT = true;
			}
		},
		openMenu() {
			this.menuShow = true;
			let that = this;
			setTimeout(() => {
				$(".nav-item").on("click", function (e) {
					that.menuShow = false;
					if ($(e.currentTarget).attr("to")){
						that.$router.push($(e.currentTarget).attr("to"));
					}
				});
			});
		},
		isShowMusic() {
			let fix_bar = $("#fix-bar");
			this.showMusic = !this.showMusic;
			this.showMusic ? fix_bar.show() : fix_bar.hide();
		},
		search_click(){
			this.is_search = true
			this.$nextTick(() => {
				this.$refs.search.focus();
			})
		},
		search() {
			this.is_search = false;
			let title = this.title;
			this.title = '';
			this.$router.push({
				path: "/search",
				query: {
					title: title
				}
			})
		}
	},
};
</script>

<style>
/* 全局样式 */
*::selection {
	color: #ffffff;
	background-color: #30c2b4;
	text-shadow: none;
}

*::-moz-selection {
	color: #ffffff;
	background-color: #30c2b4;
	text-shadow: none;
}

a {
	color: #14d1b2;
	text-decoration: none;
}

*::-webkit-scrollbar {
	width: 8px;
	height: 8px;
}

*::-webkit-scrollbar-thumb {
	background-color: #49b1f5;
	background-image: -webkit-linear-gradient(
		45deg,
		rgba(255, 255, 255, 0.4) 25%,
		transparent 25%,
		transparent 50%,
		rgba(255, 255, 255, 0.4) 50%,
		rgba(255, 255, 255, 0.4) 75%,
		transparent 75%,
		transparent
	);
}

*::-webkit-scrollbar-track {
	background-color: transparent;
}

#app {
	width: 100%;
	height: 100%;
	top: 0;
	left: 0;
	bottom: 0;
	position: absolute;
	overflow-y: auto;
	overflow-x: hidden;
}

#app {
	width: 100%;
	height: 100%;
}

/* 布局 */
.topT {
	position: absolute;
	top: 0;
	left: 0;
	width: 100%;
	height: 60px;
	line-height: 60px;
	background-color: transparent;
	color: #ffffff;
}

.topT .nav .nav-item a {
	color: #ffffff;
}

.topT .logo a {
	color: #ffffff;
}

.topS {
	position: fixed;
	top: 0;
	left: 0;
	z-index: 999;
	width: 100%;
	height: 60px;
	line-height: 60px;
	background: rgba(255, 255, 255, 0.8);
	color: #000000;
}

.topS .nav-item a {
	color: #000000;
}

.topS .logo a {
	color: #000000;
}

.logo {
	font-size: 20px;
	font-weight: bold;
	padding-left: 20px;
}

.logo a {
	text-decoration: none;
}

.nav {
	position: relative;
	padding: 0 20px;
	background: transparent;
	border-radius: 2px;
	font-size: 0;
}

.nav-item {
	position: relative;
	display: inline-block;
	vertical-align: middle;
	font-size: 14px;
	line-height: 60px;
	list-style: none;
	padding: 0 20px;
}

.nav a {
	text-decoration: none;
}

.nav-item-a a:hover {
	color: #49b1f5;
}

/*利用:before实现下划线宽度从0-100%*/
.nav-item:before {
	content: "";
	position: absolute;
	top: -5px;
	width: 0;
	height: 100%;
	border-bottom: 5px solid #49b1f5;
	transition: 0.2s all linear; /*动画效果*/
	right: 100%; /*下划线从右侧开始显示*/
	cursor: pointer;
}

.nav-item:hover:before {
	right: 0; /*鼠标滑过时，下划线从右向左移动*/
	width: 100%; /*同时，下划线宽度从0-100%*/
}

.nav-item:hover ~ .nav-item:before {
	/*~ 选择器：查找指定元素后面的所有兄弟结点*/
	left: 0; /*处于hover后面元素的下划线从左侧开始显示*/
}

.footer {
	color: #ffffff;
	padding: 30px;
	text-align: center;
}

.back_top {
	height: 100%;
	width: 100%;
	text-align: center;
	line-height: 30px;
	color: #ffffff;
	background-color: #1989fa;
}

/* 搜素 */
.search-main{
	position: fixed;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
}

.search-input{
	margin-top: 10vh;
	text-align: center;
}

.search-background{
	position: absolute;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	background-color: #000000;
	opacity: 0.6;
}

</style>
