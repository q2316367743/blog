<template>
    <div class="vue-box">
        <div class="content-box">
            分类列表
        </div>
    </div>
</template>

<script>
export default {
    name: "list"
}
</script>

<style scoped>

</style>