// 模拟数据 
module.exports = {
	code: 200,
	msg: 'ok',
	data: [{
			"id": 20,
			"title": "那个清晨",
			"content": "那个清晨一大早，便被母亲叫起。我有些不满，平常我是总要在床上多赖一会儿的。可当我迷迷糊糊的看到母亲紧绷的脸庞时...",
			"see_count": 356,
			"like_count": 55,
			"share_count": 13,
			"create_username": '省长',
			"is_public": 1,
			"create_time": "2019-05-12"
		},
		{
			"id": 17,
			"title": "人生，就是一场抵达",
			"content": "庄子说，人生天地之间，若白驹过隙，忽然而已。人生就是一场抵达，我们总以为来日方长...",
			"see_count": 200,
			"like_count": 12,
			"share_count": 6,
			"create_username": '小言',
			"is_public": 1,
			"create_time": "2019-05-12"
		},
		{
			"id": 11,
			"title": "气质女生与世界先生",
			"content": "我把衣柜翻了个底朝天，花花绿绿地堆了满床。谢雨帆盘腿坐在电脑前打游戏，嗑着瓜子眼皮也不抬一下，半晌才悠悠地吐出一句...",
			"see_count": 240,
			"like_count": 22,
			"share_count": 15,
			"create_username": 'fan哈',
			"is_public": 2,
			"create_time": "2019-05-10"
		},
		{
			"id": 9,
			"title": "善待朋友，珍惜拥有",
			"content": "不要弄丢，一个对你好的人；不要漠视，一份待你深的情。不是谁都能包容你的臭脾气，更不是谁都能一直等下去...",
			"see_count": 2420,
			"like_count": 122,
			"share_count": 95,
			"create_username": '小丸子',
			"is_public": 2,
			"create_time": "2019-05-5"
		},
		{
			"id": 7,
			"title": "爱是淡淡的忧伤",
			"content": "回味初识的那一段深情爱恋，清晰的面容，熟悉的身影，悦耳的声音，在某个深夜恍然想起。那是一个深秋的夜晚，我们相拥而坐...",
			"see_count": 320,
			"like_count": 12,
			"share_count": 5,
			"create_username": '不值一提',
			"is_public": 1,
			"create_time": "2019-05-1"
		},
		{
			"id": 6,
			"title": "男人看了沉默,女人看了流泪",
			"content": "男人看了沉默,女人看了流泪男人看了沉默,女人看了流泪男人看了沉默,女人看了流泪男人看了沉默,女人看了流泪...",
			"see_count": 3220,
			"like_count": 11,
			"share_count": 1,
			"create_username": 'UC震惊部',
			"is_public": 1,
			"create_time": "2019-05-1"
		},
		{
			"id": 5,
			"title": "爱是淡淡的忧伤",
			"content": "回味初识的那一段深情爱恋，清晰的面容，熟悉的身影，悦耳的声音，在某个深夜恍然想起。那是一个深秋的夜晚，我们相拥而坐...",
			"see_count": 320,
			"like_count": 12,
			"share_count": 5,
			"create_username": '不值一提',
			"is_public": 1,
			"create_time": "2019-05-1"
		}
	],
	dataCount: 6379
}
