module.exports = {
	code: 200,
	msg: 'ok',
	data: [{
		"id": 1,
		"role_name": "普通用户",
		"role_info": "普通用户",
		"is_lock": 1,
		"create_time": "2018-08-17T02:33:14.000+0000"
	}, {
		"id": 11,
		"role_name": "顶级管理员",
		"role_info": "最高权限",
		"is_lock": 1,
		"create_time": "2018-08-17T02:33:14.000+0000"
	}, {
		"id": 101,
		"role_name": "超级管理员",
		"role_info": "最高权限",
		"is_lock": 2,
		"create_time": "2018-08-17T03:24:01.000+0000"
	}]
}
